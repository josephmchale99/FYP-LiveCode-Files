package liveCode.code;

public class GlobeVars {

	
	public static final String databaseURL = "jdbc:mysql://sql160.main-hosting.eu/u259993745_LiveCode";
	public static final String databaseUsername = "u259993745_root";
	public static final String databasePassword = "Password12@";
	
	public static final String databaseURL2 = "jdbc:mysql://localhost:3306/livecode?zeroDateTimeBehavior=CONVERT_TO_NULL";
	public static final String databaseUsername2 = "root";
	public static final String databasePassword2 = "";
	
	
	public static final String serverURL = "http://spring-boot-live-code.herokuapp.com/homer";
	
	public static final String processingConsoleLocation = "C:\\Users\\josep\\AppData\\Roaming\\Processing\\console";
	
	
	
	
}
