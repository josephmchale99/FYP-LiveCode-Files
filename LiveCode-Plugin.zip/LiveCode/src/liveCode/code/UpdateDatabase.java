package liveCode.code;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class UpdateDatabase {

	Connection con = null;
    ResultSet rs = null;
    Statement st;
	
    
    
	/**
	 * This will send the error to the database and all the important information about the error
	 * @param name the error name
	 * @param type the type of error
	 * @param message the whole error message
	 * @param active if the error is active
	 * @param priority the priority level of the error
	 * @param student_ID the id of the student which encountered the error
	 */
	public void addError(String name, String type, String message, int active, int priority, int student_ID) {
		try {			
			con = DriverManager.getConnection(GlobeVars.databaseURL, GlobeVars.databaseUsername, GlobeVars.databasePassword);
	        st = (Statement)con.createStatement();
	        st.executeUpdate("INSERT INTO error (Name, Type, Message, Active, Priority, Student_ID)"
	        		+ "VAlues ('"+name+"','"+type+"','"+message+"','"+active+"','"+priority+"','"+student_ID+"')");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
	
	
	/**
	 * This method will take a student's email and find their unique id from the database
	 * @param email to hold the student's email
	 * @return is the student's unique id from the database
	 */
	public int getStudentID(String email) {		
		Integer studentID = null;
		try {			
			con = DriverManager.getConnection(GlobeVars.databaseURL, GlobeVars.databaseUsername, GlobeVars.databasePassword);
	        st = (Statement)con.createStatement();
	        
	        rs = st.executeQuery("SELECT * FROM student WHERE Email='" +email+ "'");
	        rs.next();
	        studentID = rs.getInt("Student_ID");
	        
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		return studentID;
	}
	
	
	
	
}
