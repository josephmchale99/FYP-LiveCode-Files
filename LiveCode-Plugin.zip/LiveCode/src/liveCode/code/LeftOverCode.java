
/*
/*



		ArrayList<String> fileStorage = new ArrayList<String>();
		
		fileStorage.add("ArrayIndexOutOfBoundsException: Index 5 out of bounds for length 3");
		fileStorage.add("dave");
		fileStorage.add("ArrayIndexOutOfBoundsException: Index 5 out of bounds for length 3");
		fileStorage.add("ArrayIndexOutOfBoundsException: Index 5 out of bounds for length 3");
		fileStorage.add("banana");
		fileStorage.add("ArrayIndexOutOfBoundsException: Index 5 out of bounds for length 3");
		fileStorage.add("ArrayIndexOutOfBoundsException: Index 2 out of bounds for length 5");
		
		ArrayList<String> two = new ArrayList<String>();
		two = errorSending.removeDuplicates(fileStorage);
		
		 for (int i = 0; i < two.size(); i++) {
		      System.out.println(two.get(i));
		    }

public void theTest() {
		
		File dave = null;
		try {
			dave = retrieveFile(GlobeVars.processingConsoleLocation, "err");
			
			
			System.out.println(dave);
			
			if (dave.length() == 0) {
				System.out.println("file is empty");				
			} else {
				System.out.println("file is full");
			}
			
			
		} catch (Exception e){
			System.out.println("error= " + e);
		}
		
		try {
			Scanner input = new Scanner(dave);
			while (input.hasNextLine())
			{
			   System.out.println(input.nextLine());
			}
			
		} catch (Exception e){
			System.out.println("error 2 = " + e);
		}			
		
	}




*
	public void addError2() {
		
		String name = "name third";
		String type = "type";
		String message = "message";
		int active = 1;
		int priority = 1;
		int student_ID = 1;
		
		
		try {			
			con = DriverManager.getConnection(GlobeVars.databaseURL, GlobeVars.databaseUsername, GlobeVars.databasePassword);
	        st = (Statement)con.createStatement();
	        st.executeUpdate("INSERT INTO error (Name, Type, Message, Active, Priority, Student_ID)"
	        		+ "VAlues ('"+name+"','"+type+"','"+message+"','"+active+"','"+priority+"','"+student_ID+"')");
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		
	}
	
	
	
	public static void main (String args[]) {
		//UpdateDatabase updateDatabase = new UpdateDatabase();
		//updateDatabase.addError2();
	}
	
	
	public void fuck(String string) {
		try {
            URL url = new URL(GlobeVars.serverURL + "/sendErrorss");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");            
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            
            String input = string;
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            
            os.flush();
            
            
            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
            	throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }


            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
	  
	  
	  
  }
	
package liveCode.connection.error;

import java.io.File;
import java.util.Scanner;

import liveCode.connection.database.UpdateDatabase;

public class SendingErrors {
	
	private String errorMessage;
	
	private String message;
	private String name;
	private String type;
	
		
	
	public void startCode(int id, String error) {
		readError();
		
		int StudentID = id;		
		UpdateDatabase updateDatabase = new UpdateDatabase();
		updateDatabase.addError(getName(), getType(), getMessage(), 1, 1, StudentID);
	}
	
	
	
	
	
	/**
	 * reads the error file
	 * formats the string into the relevant variables
	 * and r
	 //*/
	/*
	public void readError() {
		
		
		try {
			
			File file = new File("ErrorStorage.txt");
			if(file.exists()) {
				Scanner scanner = new Scanner( new File("ErrorStorage.txt") );
				String text = scanner.useDelimiter("\\A").next();
				scanner.close();
				System.out.println(text);
				
				errorMessage = text;
				
				
				String errorMessageParts[] = errorMessage.split("\\.");			
				String errorMessageParts2[] = errorMessageParts[2].split(":");
				
				message = errorMessageParts2[1];
				errorMessage = errorMessage.trim();
				name = errorMessageParts[1];
				type = errorMessageParts2[0];
			} 
			
			
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
	
	
	
	
	//getters and setters for the variables needed
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	
}
	
	
	package liveCode.connection.error;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

import org.apache.commons.io.*;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;

import liveCode.connection.server.GlobeVars;

/**
 * Class is to start recording any of the student's errors
 * and stores it to a txt file
 *
 *//*
public class Error {

	
	/**
	 * runs the code needed
	 *//*
	public static void main(String[] args) {
		
		Error error = new Error();
		//error.startErrorRecording();
		/*
		error.test();
		
		int[] java = new int[2];
		int beta = java[5];
		
		*/
		/*
		File dave = null;
		try {
			dave = error.retrieveFile(GlobeVars.processingConsoleLocation, "err");
			
			
			System.out.println(dave);
			
			if (dave.length() == 0) {
				System.out.println("file is empty");				
			} else {
				System.out.println("file is full");
			}
			
			
		} catch (Exception e){
			System.out.println("error= " + e);
		}
		
		try {
			Scanner input = new Scanner(dave);
			while (input.hasNextLine())
			{
			   System.out.println(input.nextLine());
			}
			
		} catch (Exception e){
			System.out.println("error 2 = " + e);
		}	
		*//*
		
		error.fuck();
		
		
		
		
	}
	
	
	public void theTest() {
		
		File dave = null;
		try {
			dave = retrieveFile(GlobeVars.processingConsoleLocation, "err");
			
			
			System.out.println(dave);
			
			if (dave.length() == 0) {
				System.out.println("file is empty");				
			} else {
				System.out.println("file is full");
			}
			
			
		} catch (Exception e){
			System.out.println("error= " + e);
		}
		
		try {
			Scanner input = new Scanner(dave);
			while (input.hasNextLine())
			{
			   System.out.println(input.nextLine());
			}
			
		} catch (Exception e){
			System.out.println("error 2 = " + e);
		}	
		
		
	}
	
	
	/* Taken from:
	 * https://stackoverflow.com/a/12337559
	 * It will look in a directory and look for the most update to date file
	 * Of a certain file type
	 * @filePath is the path to the directory
	 * @ext is the file extension for the file that is needed
	 * 
	 * It returns the most up to date file in the File type
	 *//*
	public File retrieveFile(String filePath, String ext) {
		File theNewestFile = null;
	    File dir = new File(filePath);
	    FileFilter fileFilter = new WildcardFileFilter("*." + ext);
	    File[] files = dir.listFiles(fileFilter);

	    if (files.length > 0) {
	        /** The newest file comes first **//*
	        Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
	        theNewestFile = files[0];
	    }

	    return theNewestFile;
	}
	
	/**
	 * records the error from the console log
	 * stores them into error.tcxt
	 */
	/*
	public void startErrorRecording() {
		
		try {
			PrintStream pst = new PrintStream("ErrorStorage.txt");  
			System.setErr(pst);
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void newErrorRecording() {
		try {
			
			ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
			PrintStream pst = new PrintStream(byteArray);  
			System.setErr(pst);
			
			String tester = byteArray.toString(StandardCharsets.UTF_8);
			
			/*
			try {
	            URL url = new URL("http://localhost:8998/sendErrorss");
	            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	            conn.setRequestMethod("POST");            
	            conn.setDoOutput(true);
	            conn.setRequestProperty("Content-Type", "application/json");
	            
	            String input = "issue";
	            
	            OutputStream os = conn.getOutputStream();
	            os.write(input.getBytes());
	            
	            os.flush();
	            
	            
	            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
	            	throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
	            }
	            
	            
	            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
	            
	            String output;
	            System.out.println("Output from Server .... \n");
	            while ((output = br.readLine()) != null) {
	            	System.out.println(output);
	            }


	            conn.disconnect();
	            
	        } catch (Exception e){
	            System.out.println(e);
	        }
	        *//*
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
	
	public void test() {
		/*
		try {
            URL url = new URL("http://localhost:8998/sendError");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");            
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            
            String input = "2";
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            
            os.flush();
            
            
            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
            	throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }


            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
        
        */
		/*
		try {
			OutputStream myCustomReportingStream = new OutputStream() {
				  
				ByteArrayOutputStream buffer = new ByteArrayOutputStream();
					
				  @Override public void write(int lines) {
				    			    
					if (lines == '\r') {}	    
					else if (lines == '\n') {
				      process(new String(buffer.toByteArray(), StandardCharsets.UTF_8));
				      buffer.reset();
				    } else {
				      buffer.write(lines);
				    }
				  }

				  private void process(String message) {
				    
					  try {
				            URL url = new URL("http://localhost:8998/sendErrorss");
				            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				            conn.setRequestMethod("POST");            
				            conn.setDoOutput(true);
				            conn.setRequestProperty("Content-Type", "application/json");
				            
				            String input = message;
				            
				            OutputStream os = conn.getOutputStream();
				            os.write(input.getBytes());
				            
				            os.flush();
				            
				            
				            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				            	throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
				            }
				            
				            
				            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				            
				            String output;
				            System.out.println("Output from Server .... \n");
				            while ((output = br.readLine()) != null) {
				            	System.out.println(output);
				            }


				            conn.disconnect();
				            
				        } catch (Exception e){
				            System.out.println(e);
				        }
					  
					  
					  
				  }
			};
			System.setErr(new PrintStream(myCustomReportingStream, true, StandardCharsets.UTF_8));
			System.setOut(new PrintStream(myCustomReportingStream, true, StandardCharsets.UTF_8));
			
			
			
		} catch (Exception e){
			System.out.println(e);
		}		

	}
	
	
	
	
	public void fuck() {
		try {
            URL url = new URL(GlobeVars.serverURL + "/sendErrorss");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");            
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            
            String input = "bonjournow";
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            
            os.flush();
            
            
            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
            	throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }


            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
	  
	  
	  
  }
	
	
	
	
	
	
	public static void main (String[] args) {
		ErrorSending errorSending = new ErrorSending(1);
		//errorSending.runningCode();
		//errorSending.testingt();
		
		errorSending.fuck("wtf");
		
	}
	
	
	
	

	
	
}

	
	
	
	public void runCode() {
		Connection connection = new Connection();
		connection.runServer();	
		
		UpdateDatabase updateDatabase = new UpdateDatabase();		
		studentID = updateDatabase.getStudentID(studentEmail);
		
		
		
		ErrorSending errorSending = new ErrorSending(connection.getStudentID());
		errorSending.runningCode();
	}
	
	
	
	
	
	
	public void testingt() {
		//int id = 1;
		try {
			PrintWriter writer = new PrintWriter("the-file-name.txt", "UTF-8");
			writer.println("The first line");
			writer.println("The second line");
			writer.close();
		      
		    } catch (IOException e) {
		      
		      e.printStackTrace();
		    }
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


























































*/