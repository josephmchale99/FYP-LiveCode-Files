package liveCode.code;

public class LiveCodeRunner {
	
	
	public String studentEmail;
	public int studentID;
	
	/*
	 * Constructor for the class
	 */
	public LiveCodeRunner(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	
	
	/*
	 * This method will run the code for the library
	 * will first display the student screen
	 * then will check if any errors need to be sent to the database
	 */
	public void runCode() {
		
		DisplayStudentScreen displayStudentScreen = new DisplayStudentScreen(studentEmail);
		displayStudentScreen.runCode();
		
		ErrorSending errorSending = new ErrorSending(displayStudentScreen.getStudentID());
		errorSending.runningCode();
		
	}
	
	public static void main (String[] args) {
		
		//DisplayStudentScreen displayStudentScreen = new DisplayStudentScreen("190121123@aston.ac.uk");
		//displayStudentScreen.runCode();
		
		
		
	}
	
	
	
	/*
	public static void main(String args[]) {
		LiveCodeRunner liveCodeRunner = new LiveCodeRunner("wayne@outlook.com");
		liveCodeRunner.runCode2();
	}
	
	*/
	
	
}
	
	
