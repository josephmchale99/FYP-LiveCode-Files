package liveCode.code;

import javax.swing.*;
import java.awt.*;

public class DisplayStudentScreen {
	
	public JFrame jframe;
	
	public String email;
	public int studentID;
	public UpdateDatabase updateDatabase;
	
		
	
	/**
	 * Constructor for the class	
	 * @param email the email of the student
	 */
	public DisplayStudentScreen(String email) {
		this.email = email;
		updateDatabase = new UpdateDatabase();
		studentID = updateDatabase.getStudentID(email);
	}
	
	
	
	/**
	 * A method to run the important methods of the class
	 */
	public void runCode() {
		showDisplay(studentID);
	}
	
	
		
	
	/**
	 * This method will create a jframe
	 * this will hold the student's unique identifier
	 * @param id  is the unique id of the student
	 */
	public void showDisplay(int id) {	
		jframe = new JFrame("LiveCode Identifier");
		jframe.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		
		JLabel textLabel = new JLabel("ID: " + id, SwingConstants.CENTER);
		textLabel.setPreferredSize(new Dimension(200, 200));
		textLabel.setFont(new Font("Verdana", Font.BOLD, 30));
		jframe.getContentPane().add(textLabel, BorderLayout.CENTER);
		
		jframe.setLocationRelativeTo(null);
		jframe.pack();
		jframe.setVisible(true);
		jframe.setLocation(-10, 0);
		jframe.setAlwaysOnTop( true );	
		
	}
	
	
	/** 
	 * a getter for the studentID 
	 * @return the student id variable
	 */
	public int getStudentID() {
		return studentID;
	}
	
	
	
	
	
	
}
