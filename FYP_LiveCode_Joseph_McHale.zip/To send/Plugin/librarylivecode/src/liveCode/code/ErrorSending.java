package liveCode.code;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;

/**
 * @author josep
 *
 */
/**
 * @author josep
 *
 */
public class ErrorSending {
	
	public int studentID;
	
	public ErrorSending(int id) {
		studentID = id;
	}
	
	
	
	
	/*
	 * This class will run the main code for sending an error
	 * it will find the error file and store it in a string
	 * then it will remove duplicate errors
	 * then send it to the database
	 */
	public void runningCode() {
		File file = null;
		file = retrieveFile(GlobeVars.processingConsoleLocation, "err");
		
		//Will check if the retrieved file has any contents to it.
		if (file.length() == 0) {
			System.out.println("file is empty");				
		} else {
			
			
			ArrayList<String> fileStorage = new ArrayList<String>();
			fileStorage = readFile(file);
			
			
			ArrayList<String> fileStorageRemoved = new ArrayList<String>();
			fileStorageRemoved = removeDuplicates(fileStorage);
			
			for (int i = 0; i < fileStorageRemoved.size(); i++) {
				String error = fileStorageRemoved.get(i);
				if (error.contains(":")) {
					sendRegularError(error);
				} else {
					sendMiscError(error);
				}
			}
		}
		
	}
	
	
	/* Taken from:
	 * https://stackoverflow.com/a/12337559
	 * It will look in a directory and look for the most update to date file
	 * Of a certain file type
	 * @filePath is the path to the directory
	 * @ext is the file extension for the file that is needed
	 * 
	 * It returns the most up to date file in the File type
	 */
	public File retrieveFile(String filePath, String ext) {
		File theNewestFile = null;
	    File dir = new File(filePath);
	    FileFilter fileFilter = new WildcardFileFilter("*." + ext);
	    File[] files = dir.listFiles(fileFilter);

	    if (files.length > 0) {
	        /** The newest file comes first **/
	        Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
	        theNewestFile = files[0];
	    }

	    return theNewestFile;
	}
	
	
	/**
	 * This method will take a file and convert it to an
	 * array list containing strings
	 * @param file the file that needs to be read
	 * @return returns an array list containing the contents of the file
	 */
	public ArrayList<String> readFile(File file) {
		ArrayList<String> fileArray = new ArrayList<String>();
		
		try {
			Scanner scanner = new Scanner(file);
			
			while (scanner.hasNext()) {
				String line;
				line = scanner.nextLine();
				fileArray.add(line);
				//System.out.println(line);
			}
			scanner.close();
		} catch (Exception e){
			System.out.println(e);
		}
		
		return fileArray;
		
		
	}
	
	
	/**
	 * This method will take an array list and remove all duplicate value
	 * then it will return a new array list
	 * @param original is the array list that need duplicates removing from
	 * @return is the new array list with not duplicates
	 */
	public ArrayList<String> removeDuplicates(ArrayList<String> original){
		ArrayList<String> newArray = new ArrayList<String>();
		
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
		
		linkedHashSet.addAll(original);
		
		newArray.addAll(linkedHashSet);  
		
		
		return newArray;
	}
	
	
	/**
	 * this method will take an regular error and split it into relevant information
	 * then it will send the information needed to the database
	 * @param error is the error that needs to be sent to the database
	 */
	public void sendRegularError(String error) {
		String message;
		String name;
		String type;
		
		String errorParts[] = error.split(":");
		
		type = errorParts[0];
		message = errorParts[1];
		name = "regular";
		
		UpdateDatabase updateDatabase = new UpdateDatabase();
		updateDatabase.addError(name, type, message, 1, 1, studentID);
			
		
	}
	
	
	/**
	 * this method will take an misc/undefined error and split it into the relevant information
	 * then this information will be sent to the database
	 * @param error this will store the error that needs to be sent to the database
	 */
	public void sendMiscError(String error) {
		String message;
		String name;
		String type;
		
		type = "not defined";
		message = error;
		name = "misc";
		
		UpdateDatabase updateDatabase = new UpdateDatabase();
		updateDatabase.addError(name, type, message, 1, 1, studentID);
	}
	
	
		
	
	
	
	
}
