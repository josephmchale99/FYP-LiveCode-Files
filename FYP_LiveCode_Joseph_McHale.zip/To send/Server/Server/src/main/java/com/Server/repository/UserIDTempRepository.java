package com.Server.repository;


import com.Server.model.UserIDTemp;
import org.springframework.data.repository.CrudRepository;

public interface UserIDTempRepository extends CrudRepository<UserIDTemp, Long> {

    UserIDTemp findById(long id);
}
