package com.Server.repository;

import com.Server.model.Student;
import com.Server.model.User;
import org.springframework.data.repository.CrudRepository;

public interface StudentRepository extends CrudRepository<Student, Long> {

    Student findById(long id);
}
