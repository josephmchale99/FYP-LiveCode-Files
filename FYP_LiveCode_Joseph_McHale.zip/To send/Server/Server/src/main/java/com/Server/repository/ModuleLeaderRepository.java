package com.Server.repository;

import com.Server.model.ModuleLeader;
import com.Server.model.User;
import org.springframework.data.repository.CrudRepository;

public interface ModuleLeaderRepository extends CrudRepository<ModuleLeader, Long> {

    ModuleLeader findById(long id);
}
