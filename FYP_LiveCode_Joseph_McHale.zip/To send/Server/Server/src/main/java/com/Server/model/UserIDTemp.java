package com.Server.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserIDTemp {

    @Id
    private long id;

    public UserIDTemp(long id) {
        this.id = id;
    }

    protected UserIDTemp(){}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
