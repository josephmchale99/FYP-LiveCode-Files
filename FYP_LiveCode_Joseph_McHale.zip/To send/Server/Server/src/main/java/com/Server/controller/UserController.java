package com.Server.controller;

import com.Server.model.ModuleLeader;
import com.Server.model.Student;
import com.Server.model.User;
import com.Server.model.UserIDTemp;
import com.Server.repository.ModuleLeaderRepository;
import com.Server.repository.StudentRepository;
import com.Server.repository.UserIDTempRepository;
import com.Server.repository.UserRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    private final UserRepository userRepository;

    private final StudentRepository studentRepository;
    private final ModuleLeaderRepository moduleLeaderRepository;
    private final UserIDTempRepository userIDTempRepository;

    private int processingID = 0;

    UserController(UserRepository userRepository, StudentRepository studentRepository, ModuleLeaderRepository moduleLeaderRepository, UserIDTempRepository userIDTempRepository){
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.moduleLeaderRepository = moduleLeaderRepository;
        this.userIDTempRepository = userIDTempRepository;
    }

    @GetMapping("/")
    public String home(){
        System.out.println("connected");
        return "Welcome asdad";
    }

    @RequestMapping(method=RequestMethod.POST, value="/post")
    public void testing (@RequestBody String id){
        System.out.println("ID: " + id);
    }

    @GetMapping("/getProcessingID")
    public int getProcessingID(){
        processingID += 1;
        System.out.println(processingID);
        return processingID;
    }


    @PostMapping("/createModuleLeader")
    @ResponseBody
    public ModuleLeader createModuleLeader(@RequestBody ModuleLeader moduleLeader){
        System.out.println("id is: " + moduleLeader.getId());
        System.out.println("role is: " + moduleLeader.getRole());
        return moduleLeader;
    }


    @PostMapping("/addStudent")
    public Student addStudent(@RequestBody Student student){
        return studentRepository.save(student);
    }

    @GetMapping("/studentReturn")
    public List<Student> returnStudents(){
        return (List<Student>) studentRepository.findAll();
    }

    @DeleteMapping("/deleteStudent/{id}")
    public void deleteStudent(@PathVariable Long id){
        studentRepository.deleteById(id);
    }

    @PostMapping ("/addModuleLeader")
    public ModuleLeader addModuleLeader(@RequestBody ModuleLeader moduleLeader){
        return moduleLeaderRepository.save(moduleLeader);
    }

    @GetMapping("/moduleLeaderReturn")
    public List<ModuleLeader> returnModuleLeader(){
        return (List<ModuleLeader>) moduleLeaderRepository.findAll();
    }

    @DeleteMapping("/deleteModuleLeader/{id}")
    public void deleteModuleLeader(@PathVariable Long id){
        moduleLeaderRepository.deleteById(id);
    }

    @PostMapping("/sendUserIDTemp")
    public UserIDTemp addUserIDTemp(@RequestBody UserIDTemp userIDTemp){
        return userIDTempRepository.save(userIDTemp);
    }

    @GetMapping("/userIDTempReturn")
    public int returnUserIDTemp(){
        List<UserIDTemp> list = (List<UserIDTemp>) userIDTempRepository.findAll();
        Long id = (list.get(0).getId());
        return id.intValue();
    }

    @DeleteMapping("/deleteUserIDTemp")
    public String deleteUserIDTemp(){
        userIDTempRepository.deleteAll();
        return "deleted";
    }

    @RequestMapping(method=RequestMethod.POST, value="/sendErrorss")
    public void sendErrorss(@RequestBody String error){
        System.out.println("error is :" + error);
    }








}
