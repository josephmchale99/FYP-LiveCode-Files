package com.Server.draftcode;

public class usercontrollerdraft {
}


/*

@PostMapping("/addUser")
    public User addUser(@RequestBody User user){
        return userRepository.save(user);
    }

    @GetMapping("/userReturn")
    public List<User> returnUsers(){
        return (List<User>) userRepository.findAll();
    }

    @PostMapping("/createStudent")
    @ResponseBody
    public Student createUser(@RequestBody Student student){
        System.out.println("id is: " + student.getId());
        System.out.println("role is: " + student.getRole());
        System.out.println("processing id is: " + student.getProcessingID());
        return student;
    }


@PostMapping("/createUser")
    @ResponseBody
    public User createUser(@RequestBody User user){
        System.out.println("id is: " + user.getId());
        System.out.println("role is: " + user.getRole());
        System.out.println("processing id is: " + user.getProcessingID());
        return user;
    }





    @DeleteMapping("/deleteUser/{id}")
    public void deleteUser(@PathVariable Long id){
        userRepository.deleteById(id);
    }

    @PostMapping("/createUser")
    @ResponseBody
    public User createUser(@RequestBody User user){
        System.out.println("id is: " + user.getId());
        System.out.println("role is: " + user.getRole());
        System.out.println("processing id is: " + user.getProcessingID());
        return userRepository.save(user);
    }

    @GetMapping("/userReturn")
    public List<User> returnUsers(){
        return (List<User>) userRepository.findAll();
    }

@PostMapping("/sendID")
    public String sendID(@RequestBody int id){
        System.out.println(id);
        return "connceted";
    }

    @PostMapping("/send")
    public String send(@RequestBody Integer id){
        //sets id to http listener in java application
        //recieves value back
        //returns value back
        return "tester";
    }

    @PostMapping("/sendUserIDTemp")
    public UserIDTemp addUserIDTemp(@RequestBody UserIDTemp userIDTemp){
        return userIDTempRepository.save(userIDTemp);
    }







 */
