package com.Server.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {

    @Id
    private long id;

    private String role;
    private int processingID;

    public User(long id, String role, int processingID) {
        this.id = id;
        this.role = role;
        this.processingID = processingID;
    }

    protected User(){}



    public long getId() {
        return id;
    }

    public String getRole() {
        return role;
    }

    public int getProcessingID() {
        return processingID;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setProcessingID(int processingID) {
        this.processingID = processingID;
    }
}
