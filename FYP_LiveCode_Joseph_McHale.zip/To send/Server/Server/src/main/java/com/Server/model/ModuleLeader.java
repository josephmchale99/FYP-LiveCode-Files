package com.Server.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ModuleLeader {

    @Id
    private long id;

    private String role;

    public ModuleLeader(long id, String role) {
        this.id = id;
        this.role = role;
    }

    protected ModuleLeader(){}

    public long getId() {
        return id;
    }

    public String getRole() {
        return role;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
