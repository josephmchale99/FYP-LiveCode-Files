/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Client;

import java.io.*;
import java.net.*;

/**
 *
 * @author josep
 */

public class Client {
    
    
    
    public void get(){
        try {
            URL url = new URL("http://localhost:9000/echoGet");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            } 
               
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }

            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    
    
    
}





























/*

public static void main (String[] args){

        try{
            Socket s = new Socket("http://127.0.0.1:4040", 1555);

            PrintWriter pr = new PrintWriter(s.getOutputStream());
            pr.println("hello");
            pr.flush();

            InputStreamReader in = new InputStreamReader(s.getInputStream());
            BufferedReader bf = new BufferedReader(in);

            String str = bf.readLine();
            System.out.println("server : "+ str);


        } catch (Exception e){
            System.out.println(e);
        }
    }




*/
