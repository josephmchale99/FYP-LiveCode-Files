/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Client;

import SystemFiles.SystemSettings;
import java.io.*;
import java.net.*;

/**
 *
 * @author josep
 */
public class ClientPost {
    
    public static void main(String[] args){
       
           
        ClientPost clientPost = new ClientPost(); 
        
        
        
         
    }
    
     /**
      * This method creates a connection to the server
      * and adds the student account to the repo using
      * their role, id and processing id
      * @param id the id number for the account
      * @param role the account type
      * @param processingID the unique identifier for their processing IDE
      */
    public void addUserStudent(int id, String role, int processingID){
        try{
            
            URL url = new URL(SystemSettings.serverURL + "/addStudent");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");   
            conn.setRequestProperty("Content-Type", "application/json");  
            
            String input =  "{\"id\": \""+id+"\", \"role\": \""+role+"\", \"processingID\":\""+processingID+"\"}";
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush(); 
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }
            
            conn.disconnect();
            
            
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    /**
     * This method creates a connection to the server
     * and adds the module leader account to the repo using
     * their role and id
     * @param id the id number for the account
     * @param role the account type
     */
    public void addModuleLeader(int id, String role){
        try{
            URL url = new URL(SystemSettings.serverURL + "/addModuleLeader");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");   
            conn.setRequestProperty("Content-Type", "application/json");  
            
            String input =  "{\"id\": \""+id+"\", \"role\": \""+role+"\"}";
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush(); 
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }            
            conn.disconnect();
            
            
        } catch (Exception e){
            System.out.println(e);
        }
        
    }
    
    /**
     * This method will delete a module leader connection of the server
     * using their id
     * @param id the id of the student to be deleted
     */
    public void deleteStudent(long id){
        try{
            URL url = new URL(SystemSettings.serverURL + "/deleteStudent/" + id);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("DELETE");   
            conn.setRequestProperty("Content-Type", "application/json");  
            conn.connect();
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            System.out.println("Student deleted id: " + id);
            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    /**
     * This method will delete a module leader connection of the server
     * using their id
     * @param id the id of the module leader to be deleted
     */
    public void deleteModuleLeader(long id){
        try{
            URL url = new URL(SystemSettings.serverURL + "/deleteModuleLeader/" + id);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("DELETE");   
            conn.setRequestProperty("Content-Type", "application/json");  
            conn.connect();  
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            
            System.out.println("Module leader deleted id: " + id);
            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    /**
     * This method will fetch the repo from the server
     * format this into one string
     * and return this string
     * @param student where the repo requested is student or module leader
     * @return returns a string containing the full repo from the server
     */
    public String returnRepo(Boolean student){
        String result = null;
        if (student){
            try {
                URL url = new URL(SystemSettings.serverURL + "/studentReturn");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");            
                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
                } 

                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

                String output;
                System.out.println("Output from Server .... \n");
                while ((output = br.readLine()) != null) {
                    result = result + " - " + output;
                }
                conn.disconnect();                
                return result;
            
            } catch (Exception e){
                System.out.println(e);
            }
            
        } else {
            try {
                URL url = new URL(SystemSettings.serverURL + "/moduleLeaderReturn");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");            
                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
                } 

                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

                String output;
                System.out.println("Output from Server .... \n");
                while ((output = br.readLine()) != null) {
                    result = result + " - " + output;
                }
                conn.disconnect();
                return result;
            
            } catch (Exception e){
                System.out.println(e);
            }            
        }       
        
        return result;
    }
    
    /**
     * Sends the user ID to the processing library server
     * and gets back the unique processing IDz`
     * @param id the user id
     * @return the processing id
     */
    public Integer sendID(int id){
        Integer pID = null;
        try{
            URL url = new URL(SystemSettings.serverURL + "/post");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");   
            conn.setRequestProperty("Content-Type", "application/json");  
            
            String input =  Integer.toString(id);
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush(); 
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;            
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	pID = Integer.parseInt(output);
            }            
            conn.disconnect();
            
            return pID;
        } catch (Exception e){
            System.out.println(e);
        }
        return pID;    
    }
    
    
    
    
    

    
}
