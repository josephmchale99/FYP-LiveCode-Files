/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

import java.io.*;
import java.net.*;

/**
 *
 * @author josep
 */
public class Server {

    public static void main (String[] args){
        
        try{
            ServerSocket ss = new ServerSocket(1555);
            Socket s = ss.accept();

            System.out.println("client connected!");

            InputStreamReader in = new InputStreamReader(s.getInputStream());
            BufferedReader bf = new BufferedReader(in);

            String str = bf.readLine();
            System.out.println("client : "+ str);

            PrintWriter pr = new PrintWriter(s.getOutputStream());
            pr.println("hello");
            pr.flush();

        } catch (Exception e){
            System.out.println(e);
        }
    }
}
