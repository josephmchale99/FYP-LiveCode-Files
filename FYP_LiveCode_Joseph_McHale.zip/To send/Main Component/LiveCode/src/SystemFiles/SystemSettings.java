/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SystemFiles;

import Server.Server;
import Client.Client;

/**
 *  A class to keep all the system settings in one place
 *  Such as the database connection URL
 * @author josep
 */
public class SystemSettings {
    
    //private final String databaseURL = "jdbc:mysql://localhost:3306/livecode?zeroDateTimeBehavior=CONVERT_TO_NULL";
    
    public static final String databaseURL = "jdbc:mysql://sql160.main-hosting.eu/u259993745_LiveCode";
    public static final String databaseUsername = "u259993745_root";
    public static final String databasePassword = "Password12@";
    
    public static final String serverURL = "http://localhost:8998";
   //public static final String serverURL = "https://springbootfyplivecode-env.eba-hsypxupz.us-east-1.elasticbeanstalk.com/";
    
   // SystemSettings.databaseURL, SystemSettings.databaseUsername, SystemSettings.databasePassword, 
	
    
    
    public static void main (String[] args){
        
        
        
        
        
    }
    
    
    
    
    
    
    
}









