/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Assets.testingshite;

/**
 *
 * @author josep
 */
public class leftOveCode {
    
}

/*

//orignal post code
try {
            URL url = new URL("http://localhost:8998/post");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");            
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            
            String input = "2";
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            
            os.flush();
            
            /*
            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
            	throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }


            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }



//String input = "{\"id\": 1,\"role\": \"Asus Zenbook\",\"processingID\": 800}";

 //String input = "{\"id\": 1,\"role\": \"Asus Zenbook\",\"processingID\": 800}";
            //String jsonRequestString = "{\"access_code\" : \""+code+"\" , ";
            
            
            //String input2 = "{\"id\": 1,\"role\": \"Asus Zenbook\",\"processingID\": 800}";
            
            // : \""+id+"\", "
            // : \""+role+"\", "
            // : \""+processing+"\", "
            String input =  "{\"id\": \""+id+"\", \"role\": \""+role+"\", \"processingID\":\""+processing+"\"}";



public void tester(int id, String role, int processingID){
        try{
            URL url = new URL("http://localhost:8998/addUser");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");   
            conn.setRequestProperty("Content-Type", "application/json");  
            
            String input =  "{\"id\": \""+id+"\", \"role\": \""+role+"\", \"processingID\":\""+processingID+"\"}";
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush(); 
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }
            
            conn.disconnect();
            
            
        } catch (Exception e){
            System.out.println(e);
        }
    }

public void deleteStudent123(long id){
        try {
            URL url = new URL("http://localhost:8998/deleteUser/" + id);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("DELETE");   
            conn.setRequestProperty("Content-Type", "application/json");  
            conn.connect();
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }
            
            
            
            
            
            System.out.println("Student " + id + " deleted");
            
            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    public void tester(int id, String role, int processingID){
        try{
            URL url = new URL("http://localhost:8998/createUser");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();                     
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");   
            conn.setRequestProperty("Content-Type", "application/json");  
            
            String input =  "{\"id\": \""+id+"\", \"role\": \""+role+"\", \"processingID\":\""+processingID+"\"}";
            
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush(); 
            
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }
            
            conn.disconnect();
            
            
        } catch (Exception e){
            System.out.println(e);
        }
    }

 clientPost.tester(1, "dave", 64366);
        clientPost.tester(2, "dasd", 13666);
        clientPost.tester(3, "davagfde", 612366);
        clientPost.tester(4, "dgfdgfdave", 662316);
        clientPost.tester(5, "dsfdave", 13666);
        
        clientPost.getItems();
        
        clientPost.deleteStudent123(3);
        clientPost.getItems();
        
        /*
        clientPost.tester(66, "tester", 8485);
        clientPost.tester(67, "tester1", 843185);
        clientPost.tester(68, "tester2", 8432185);
        clientPost.tester(69, "tester3", 84185);
        clientPost.tester(70, "tester4", 82313485);
        clientPost.tester(71, "tester5", 2138485);
        clientPost.tester(72, "tester6", 138485);
        clientPost.getItems();
        
 public void getItems(){
        try {
            URL url = new URL("http://localhost:8998/userReturn");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            } 
               
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }

            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
        
    }

public static void main(String[] args){
        
        try {
            URL url = new URL("http://localhost:8998/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            } 
               
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
            	System.out.println(output);
            }

            conn.disconnect();
            
        } catch (Exception e){
            System.out.println(e);
        }
        
    }




private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        
        ClientPost clientPost = new ClientPost();
        String result = clientPost.returnRepo(false);
        System.out.println(result);
        JOptionPane.showMessageDialog(rootPane, result);
        
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        
        
        ClientPost clientPost = new ClientPost();
        System.out.println(clientPost.sendID(1));
        
        
        
        
    }                                        

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        String name = "name third";
	String type = "type";
	String message = "message";
	int active = 1;
	int priority = 1;
	int student_ID = 1;       
        
        
        try{
            con = DriverManager.getConnection(SystemSettings.databaseURL, SystemSettings.databaseUsername, SystemSettings.databasePassword);
            st = (Statement)con.createStatement();
            st.executeUpdate("INSERT INTO error (Name, Type, Message, Active, Priority, Student_ID)"
	        		+ "VAlues ('"+name+"','"+type+"','"+message+"','"+active+"','"+priority+"','"+student_ID+"')");
        } catch (Exception e) {
        
        }
        
        
        
        
    }    


 private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        ClientPost clientPost = new ClientPost();
        String result = clientPost.returnRepo(false);
        System.out.println(result);
        JOptionPane.showMessageDialog(rootPane, result);
    }  




/**
     * This method takes an email and password for a student and checks if
     * it is in the database
     * @param email user's entered email
     * @param password user's entered password
     * @return it returns if the user is found
     */ /*
    private boolean rightStudent(String email, String password){
        boolean accountExist = true;        
        try{
            //connects to database
            con = DriverManager.getConnection(SystemSettings.databaseURL, SystemSettings.databaseUsername, SystemSettings.databasePassword);
            st = (Statement)con.createStatement();
            rs = st.executeQuery("SELECT * FROM student WHERE Email='" +email+ "' AND password='" +password+ "'");
            if (!rs.isBeforeFirst()){                
                accountExist = false;
            } else {
                accountExist = true;
            }    
            
        } catch (Exception e){
            System.out.println(e);
        } 
        return accountExist;
        
        
    }

//https://stackoverflow.com/a/19005828
    /**
     * This will check the task manager on the users computer
     * and see if the processing ide is running
     * @return returns whether the processing ide is running
     */ /*
    public Boolean isProcessingRunning(){
        try{
            String line;
            String pidInfo ="";

            Process process = Runtime.getRuntime().exec(System.getenv("windir") +"\\system32\\"+"tasklist.exe");
            BufferedReader input =  new BufferedReader(new InputStreamReader(process.getInputStream()));

            while ((line = input.readLine()) != null) {
                pidInfo+=line; 
            }

            input.close();

            if(pidInfo.contains("javaw.exe"))
            {
                return true;
            }else {
                return false;
            }
            
        } catch (Exception e){
            System.out.println(e);
            return null;
        }

    }

private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        //JOptionPane.showMessageDialog(rootPane, "it works f" + email.getText() + password.getText());
                    
        //checks what type of account is selected by the user
        //and checks the database to see if the detials entered are correct
       
        /*
        boolean accountValid = true;        
        if (studentRB.isSelected()){
            //finds student
            accountValid = rightStudent(emailTextBox.getText(), passwordTextBox.getText());   
        } else if (moduleLeaderRB.isSelected()){
            //finds staff
            accountValid = rightModuleLeader(emailTextBox.getText(), passwordTextBox.getText());  
        }
        
        
        //checks if the processing ide is running and the student accouint is selected
        if (!isProcessingRunning() && studentRB.isSelected()){ 
            //outputs error message if the user is a student and they don't have processing running
            JOptionPane.showMessageDialog(rootPane, "Processing ide must be running!");
        } 
        //runs if the account is a student and procesing is running or
        //if the user is a module leader
        else {            
             //runs logging in code if the details match a valid account
            if (accountValid){  
                //if student
                if (studentRB.isSelected()){

                    //connects to server and adds student to connected accounts
                    int id = getAccountID(emailTextBox.getText(), passwordTextBox.getText(), true);
                    ClientPost clientPost = new ClientPost();                
                    int processingID = clientPost.sendID(id);                
                    clientPost.addUserStudent(id, "student", processingID);

                    //loads next screen
                    StudentUI studentUI = new StudentUI();
                    studentUI.setVisible(true);
                    //changes unique idnerifer on next screen
                    String idString = Integer.toString(id);
                    studentUI.IdentifierLabel.setText(idString);
                    //disposes current screen
                    this.dispose();
                } 
                //if staff
                else if (moduleLeaderRB.isSelected()){

                    //connects to server and adds module leader to connected accounts
                    int id = getAccountID(emailTextBox.getText(), passwordTextBox.getText(), false);
                    ClientPost clientPost = new ClientPost();
                    clientPost.addModuleLeader(id, "module leader");

                    //loads staff screen
                    StaffUI staffUI = new StaffUI();
                    staffUI.setVisible(true);

                    //loads users id to place holder lable on next screen
                    String idString = Integer.toString(id);
                    staffUI.IdPlaceholder.setText(idString);

                    this.dispose();
                }           
            } 
            //outputs error message if input details are wrong
            else {
                JOptionPane.showMessageDialog(rootPane, "Details entered don't match an account try again");
            } 
        }
        *//*
        boolean accountValid = true;    
        
        accountValid = rightModuleLeader(emailTextBox.getText(), passwordTextBox.getText());
        
        
        
        if(accountValid){
            //connects to server and adds module leader to connected accounts
            int id = getAccountID(emailTextBox.getText(), passwordTextBox.getText(), false);
            ClientPost clientPost = new ClientPost();
            clientPost.addModuleLeader(id, "module leader");

            //loads staff screen
            StaffUI staffUI = new StaffUI();
            staffUI.setVisible(true);

            //loads users id to place holder lable on next screen
            String idString = Integer.toString(id);
            staffUI.IdPlaceholder.setText(idString);

            this.dispose();

            
        } else{
            
        }
        
        
        
    }        























*/
